function openH() {
    document.location.href = "index.html";
}
function openR() {
    document.location.href = "reservations.html";
}
function openC() {
    document.location.href = "contacts.html";
}
function openA() {
    document.location.href = "about.html";
}
